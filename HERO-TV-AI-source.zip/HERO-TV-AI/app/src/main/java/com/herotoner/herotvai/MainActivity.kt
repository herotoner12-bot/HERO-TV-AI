package com.herotoner.herotvai

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "HERO TV AI"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "مساعدك الصوتي للتلفزيون"
            textSize = 19f
            setTextColor(0xFFD1D5DB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val mic = Button(this).apply {
            text = "🎙 تحدث الآن"
            textSize = 22f
            setOnClickListener { startListening() }
        }
        val youtube = Button(this).apply {
            text = "افتح يوتيوب"
            setOnClickListener { openYouTube() }
        }
        val up = Button(this).apply {
            text = "رفع الصوت"
            setOnClickListener { changeVolume(AudioManager.ADJUST_RAISE) }
        }
        val down = Button(this).apply {
            text = "خفض الصوت"
            setOnClickListener { changeVolume(AudioManager.ADJUST_LOWER) }
        }
        listOf(title, status, mic, youtube, up, down).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 12 })
        }
        setContentView(layout)
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "قل: افتح يوتيوب أو ارفع الصوت")
        }
        try {
            startActivityForResult(intent, 100)
        } catch (_: ActivityNotFoundException) {
            status.text = "خدمة التعرف على الصوت غير متوفرة على هذا الجهاز"
        }
    }

    @Deprecated("Deprecated by Android; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK) return
        val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()?.lowercase(Locale("ar")) ?: return
        status.text = "سمعت: $spoken"
        when {
            spoken.contains("يوتيوب") || spoken.contains("youtube") -> openYouTube()
            spoken.contains("ارفع") || spoken.contains("علي") || spoken.contains("أعلى") ->
                changeVolume(AudioManager.ADJUST_RAISE)
            spoken.contains("وطي") || spoken.contains("خفض") || spoken.contains("نزل") ->
                changeVolume(AudioManager.ADJUST_LOWER)
            else -> status.text = "لم أفهم الأمر. جرّب: افتح يوتيوب أو ارفع الصوت"
        }
    }

    private fun openYouTube() {
        val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "تطبيق يوتيوب غير مثبت", Toast.LENGTH_LONG).show()
    }

    private fun changeVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }
}
